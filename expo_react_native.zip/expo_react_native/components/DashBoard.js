import React, { Component } from "react";
import {
  View,
  StyleSheet,
  TouchableOpacity,
  Text,
  Image,
  ScrollView,
  SafeAreaView,
} from "react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import "react-native-gesture-handler";
import AwesomeAlert from "react-native-awesome-alerts";
import { Card, Button, Title, Paragraph } from "react-native-paper";
import Slideshow from "./SlideShow";

export default class DashBoard extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      message: "",
      showAlert: false,
      title: "",
    };
  }

  logout = async () => {
    AsyncStorage.clear();
    this.props.navigation.replace("Login");
  };

  static navigationOptions = ({ navigation }) => ({
    title: "DashBoard",
    headerStyle: {
      backgroundColor: "#131d41",
      elevation: 0,
    },
    headerTintColor: "#ffffff",
    headerTitleStyle: {
      fontWeight: "bold",
      fontSize: 24,
    },
  });

  showAlert = () => {
    this.setState({
      showAlert: true,
    });
  };

  hideAlert = () => {
    this.setState({
      showAlert: false,
      message: "",
      title: "",
    });
  };

  render() {
    const { showAlert } = this.state;
    return (
      // <View style={styles.container}>
      //   {/* <Image source={require('./../assets/logo.png')}
      //     style={{width: 200, height: 200 ,marginBottom:50 }} /> */}

      //   <TouchableOpacity
      //     style={[styles.buttonContainer, styles.loginButton]}
      //     onPress={() => this.props.navigation.navigate("HumanBodyParts")}
      //   >
      //     <Text style={{ color: "#ffffff", fontWeight: "bold" }}>
      //       Human Body Parts
      //     </Text>
      //   </TouchableOpacity>
      //   <TouchableOpacity
      //     style={[styles.buttonContainer, styles.loginButton]}
      //     onPress={() => this.props.navigation.navigate("TextRecognition")}
      //   >
      //     <Text style={{ color: "#ffffff", fontWeight: "bold" }}>
      //       Micro-Biology
      //     </Text>
      //   </TouchableOpacity>
      //   <TouchableOpacity
      //     style={[styles.buttonContainer, styles.loginButton]}
      //     onPress={() => this.props.navigation.navigate("AnimalRecognition")}
      //   >
      //     <Text style={{ color: "#ffffff", fontWeight: "bold" }}>Zoology</Text>
      //   </TouchableOpacity>
      //   <TouchableOpacity
      //     activeOpacity={0.7}
      //     onPress={() => this.props.navigation.navigate("Chat")}
      //     style={styles.touchableOpacityStyle}
      //   >
      //     <Image
      //       source={require("./../assets/bot.png")}
      //       style={styles.floatingButtonStyle}
      //     />
      //   </TouchableOpacity>
      //   <TouchableOpacity
      //     style={[styles.buttonContainer, styles.registerButton]}
      //     onPress={this.logout}
      //   >
      //     <Text style={{ color: "#ffffff", fontWeight: "bold" }}>Logout</Text>
      //   </TouchableOpacity>

      //   <AwesomeAlert
      //     show={showAlert}
      //     title={this.state.title}
      //     message={this.state.message}
      //     closeOnTouchOutside={true}
      //     closeOnHardwareBackPress={false}
      //     showCancelButton={true}
      //     cancelText="Close"
      //     cancelButtonColor="#AEDEF4"
      //     onCancelPressed={() => {
      //       this.hideAlert();
      //     }}
      //   />
      // </View>
      <ScrollView style={styles.container2}>
        <View style={styles.cardWrapper}>
          <Card style={styles.card}>
            <View style={styles.cardContentWrapper}>
              <Card.Content style={styles.cardContent}>
                <Title style={styles.title}>Welcome to Clever Zone</Title>
                <Text style={styles.description}>
                  We digitalized your syllabus
                </Text>
              </Card.Content>
              <Image
                source={require("./../assets/homecard.png")}
                style={styles.cardImage}
              />
            </View>
          </Card>
        </View>
        <View style={styles.row}>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate("HumanBodyParts")}
            style={styles.cardWrapper}
          >
            <Card style={styles.card}>
              <Card.Content style={styles.cardContent2}>
                <Title style={styles.title2}>Anatomy</Title>
              </Card.Content>
              <Image
                source={require("./../assets/human.png")}
                style={styles.cardImage2}
              />
            </Card>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate("TextRecognition")}
            style={styles.cardWrapper}
          >
            <Card style={styles.card}>
              <Card.Content style={styles.cardContent2}>
                <Title style={styles.title2}>Micro-Bio</Title>
              </Card.Content>
              <Image
                source={require("./../assets/micro.png")}
                style={styles.cardImage2}
              />
            </Card>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => this.props.navigation.navigate("AnimalRecognition")}
            style={styles.cardWrapper}
          >
            <Card style={styles.card}>
              <Card.Content style={styles.cardContent2}>
                <Title style={styles.title2}>Zoology</Title>
              </Card.Content>
              <Image
                source={require("./../assets/animal.png")}
                style={styles.cardImage2}
              />
            </Card>
          </TouchableOpacity>

          <AwesomeAlert
            show={showAlert}
            title={this.state.title}
            message={this.state.message}
            closeOnTouchOutside={true}
            closeOnHardwareBackPress={false}
            showCancelButton={true}
            cancelText="Close"
            cancelButtonColor="#AEDEF4"
            onCancelPressed={() => {
              this.hideAlert();
            }}
          />
        </View>

        <View
          style={{
            flexDirection: "row",
            marginTop: 10,
            alignContent: "center",
            justifyContent: "center",
          }}
        >
          <Text style={{ fontWeight: "bold", fontSize: 12 }}>
            "Discover life's stories in every cell with our biology app."
          </Text>
        </View>
        <View
          style={{
            flexDirection: "row",
            marginTop: 5,
            alignContent: "center",
            justifyContent: "center",
          }}
        >
          <Text
            style={{
              fontWeight: "bold",
              fontSize: 10,
              color: "grey",
              marginLeft: 10,
              marginRight: 10,
              marginBottom: 10,
            }}
          >
            Clever Zone covers the 9th, 10 th, 11th lessons of your syllabus.
            Hope this will help you to get a better understanding of your
            syllabus.
          </Text>
        </View>

        <View>
          <Slideshow />
        </View>
        <View>
          <Text>hellow</Text>
        </View>
        <View>
          <TouchableOpacity
            activeOpacity={0.7}
            onPress={() => this.props.navigation.navigate("Chat")}
            style={styles.touchableOpacityStyle}
          >
            <Image
              source={require("./../assets/bot.png")}
              style={styles.floatingButtonStyle}
            />
          </TouchableOpacity>
        </View>
      </ScrollView>
    );
  }
}

const styles = StyleSheet.create({
  container2: {
    flex: 1,
    backgroundColor: "lightgrey",
  },
  cardWrapper: {
    marginTop: 20,
    paddingHorizontal: 10,
  },
  card: {
    backgroundColor: "white",
    borderRadius: 8,
    padding: 10,
  },
  cardContentWrapper: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  cardContent: {
    flex: 1,
  },
  title: {
    color: "darkblue",
    fontWeight: "bold",
  },
  description: {
    color: "grey",
  },
  cardImage: {
    width: 60,
    height: 60,
    marginRight: 10,
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#ffffff",
  },
  input: {
    borderBottomWidth: 1,
    width: 80 + "%",
    height: 45,
    marginBottom: 20,
    flexDirection: "row",
    alignItems: "center",
    marginLeft: 4,
    borderBottomColor: "#c4c4c4",
    color: "#000000",
  },
  buttonContainer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    marginBottom: 10,
    width: 80 + "%",
    height: 40,
    borderRadius: 60,
  },
  loginButton: {
    backgroundColor: "#131d41",
  },
  touchableOpacityStyle: {
    position: "absolute",
    width: 50,
    height: 50,
    alignItems: "center",
    justifyContent: "center",
    right: 30,
    bottom: 30,
  },
  floatingButtonStyle: {
    resizeMode: "contain",
    width: 80,
    height: 80,
  },
  registerButton: {
    backgroundColor: "#4ff47c",
  },
  row: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 10,
  },
  cardWrapper: {
    flex: 1,
    margin: 10,
  },
  card: {
    elevation: 3,
  },
  cardContent: {
    padding: 10,
  },
  cardContent2: {
    padding: 10,
    paddingBottom: 0,
  },
  title2: {
    fontSize: 12,
    fontWeight: "bold",
    textAlign: "center",
  },
  cardImage2: {
    width: 100,
    height: 100,
    resizeMode: "cover",
  },
});
