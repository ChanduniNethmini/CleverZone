import React from "react";
import { View, Image, StyleSheet } from "react-native";
import Swiper from "react-native-swiper";

const slides = [
  {
    title: "Slide 1 Title",
    description: "Slide 1 Description",
  },
  {
    title: "Slide 1 Title",
    description: "Slide 1 Description",
  },
  {
    title: "Slide 1 Title",
    description: "Slide 1 Description",
  },
];

const Slideshow = () => {
  return (
    <View style={styles.container}>
      <Swiper style={styles.wrapper} showsButtons={false} autoplay={true}>
        {slides.map((slide, index) => (
          <View key={index} style={styles.slide}>
            <Text style={styles.title}>{slide.title}</Text>
            <Text style={styles.description}>{slide.description}</Text>
          </View>
        ))}
      </Swiper>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    marginTop: 10,
    height: 120,
  },
  title: {
    fontSize: 24, // Adjust the font size as needed
    fontWeight: "bold", // Adjust the font weight as needed
    color: "black", // Adjust the text color as needed
  },
  description: {
    fontSize: 16, // Adjust the font size as needed
    color: "gray", // Adjust the text color as needed
  },
});

export default Slideshow;
